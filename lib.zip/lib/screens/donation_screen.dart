import 'package:flutter/material.dart';

class DonationScreen extends StatefulWidget {
  const DonationScreen({Key? key}) : super(key: key);

  @override
  State<DonationScreen> createState() => _DonationScreenState();
}

class _DonationScreenState extends State<DonationScreen> {
  final List<String> categories = [
    'Food',
    'Hygienic Products',
    'Clothes',
    'Books',
    'Bedding',
    'Money',
    'Toys',
    'Blood'
  ];
  final Map<String, bool> selectedCategories = {};
  String weight = '';
  String description = '';
  TimeOfDay? selectedTime;
  String? selectedPaymentMethod;
  final List<String> paymentMethods = ['Cash', 'Credit Card', 'PayPal'];

  @override
  void initState() {
    super.initState();
    for (var category in categories) {
      selectedCategories[category] = false;
    }
  }

  void _submitForm() {
    // Validate input fields
    if (selectedCategories.values.every((value) => !value)) {
      _showErrorDialog("Please select at least one category.");
      return;
    }
    if (weight.isEmpty) {
      _showErrorDialog("Please enter the weight.");
      return;
    }
    if (description.isEmpty) {
      _showErrorDialog("Please enter a description.");
      return;
    }
    if (selectedTime == null) {
      _showErrorDialog("Please select an order time.");
      return;
    }
    if (selectedPaymentMethod == null) {
      _showErrorDialog("Please select a payment method.");
      return;
    }

    // If all fields are valid, print the form data
    print('Selected Categories: ${selectedCategories.entries.where((entry) => entry.value).map((entry) => entry.key).toList()}');
    print('Weight: $weight');
    print('Description: $description');
    print('Order Time: ${selectedTime?.format(context)}');
    print('Payment Method: $selectedPaymentMethod');
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Error"),
          content: Text(message),
          actions: [
            TextButton(
              child: const Text("OK"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  void _showCategoryDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Select Categories"),
          content: SingleChildScrollView(
            child: ListBody(
              children: categories.map((category) {
                return CheckboxListTile(
                  title: Text(category),
                  value: selectedCategories[category],
                  onChanged: (bool? value) {
                    setState(() {
                      selectedCategories[category] = value!;
                    });
                  },
                  activeColor: Theme.of(context).colorScheme.primary,
                );
              }).toList(),
            ),
          ),
          actions: [
            TextButton(
              child: const Text("Done"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Donation Form"),
        backgroundColor: Theme.of(context).colorScheme.primary,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Select Categories:", style: TextStyle(fontSize: 18)),
            TextButton(
              onPressed: _showCategoryDialog,
              child: Text(
                'Choose Categories',
                style: TextStyle(color: Theme.of(context).colorScheme.primary),
              ),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8.0,
              children: selectedCategories.entries
                  .where((entry) => entry.value)
                  .map((entry) => Chip(
                        label: Text(entry.key),
                        deleteIcon: const Icon(Icons.close),
                        onDeleted: () {
                          setState(() {
                            selectedCategories[entry.key] = false;
                          });
                        },
                      ))
                  .toList(),
            ),
            const SizedBox(height: 16),
            TextField(
              decoration: InputDecoration(
                labelText: "Weight (kg)",
                labelStyle: TextStyle(color: Theme.of(context).colorScheme.primary),
                focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Theme.of(context).colorScheme.primary),
                ),
              ),
              keyboardType: TextInputType.number,
              onChanged: (value) {
                weight = value;
              },
            ),
            const SizedBox(height: 16),
            TextField(
              decoration: InputDecoration(
                labelText: "Description",
                labelStyle: TextStyle(color: Theme.of(context).colorScheme.primary),
                focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Theme.of(context).colorScheme.primary),
                ),
              ),
              maxLines: 3,
              onChanged: (value) {
                description = value;
              },
            ),
            const SizedBox(height: 16),
            TextButton(
              onPressed: () async {
                final TimeOfDay? time = await showTimePicker(
                  context: context,
                  initialTime: TimeOfDay.now(),
                );
                if (time != null) {
                  setState(() {
                    selectedTime = time;
                  });
                }
              },
              child: Text(
                selectedTime == null
                    ? 'Select Order Time'
                    : 'Selected Time: ${selectedTime!.format(context)}',
                style: TextStyle(color: Theme.of(context).colorScheme.primary),
              ),
            ),
            const SizedBox(height: 16),
            DropdownButton<String>(
              hint: const Text("Select Payment Method"),
              value: selectedPaymentMethod,
              onChanged: (String? newValue) {
                setState(() {
                  selectedPaymentMethod = newValue;
                });
              },
              items: paymentMethods.map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value, style: TextStyle(color: Theme.of(context).colorScheme.onBackground)),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _submitForm,
              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.white,
                backgroundColor: Theme.of(context).colorScheme.primary,
              ),
              child: const Text("Submit Donation"),
            ),
          ],
        ),
      ),
    );
  }
} 
